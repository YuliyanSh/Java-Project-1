package project3;

// credit card information

import java.util.Vector;

public class CreditCard {
    // instance variables
    private String creditCardNumber;
    private Vector<String> creditCardCodes;
    private Cipher cipher;
    private static final int MAXIMUM_CODES = 12; // max number of encryption codes possible for a credit card (fixed to be 12)
    private int numberOfCodes; 
    
    
    // constructors
    public CreditCard(String creditCardNumber, Vector<String> creditCardCodes) {
        setCreditCardNumber(creditCardNumber);
        setCreditCardCodes(creditCardCodes);
        this.cipher = new Cipher(1);
        this.numberOfCodes = 0;
    }

    public CreditCard(String creditCardNumber) {
        this(creditCardNumber, new Vector<String>());
    }
    

    // instance methods
    public String getCreditCardNumber() {
        return creditCardNumber;
    }

    public void setCreditCardNumber(String creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public Vector<String> getCreditCardCodes() {
        return creditCardCodes;
    }

    public void setCreditCardCodes(Vector<String> creditCardCodes) {
        this.creditCardCodes = creditCardCodes;
    }

    public int getNumberOfCodes() {
        return numberOfCodes;
    }

    public void setNumberOfCodes(int numberOfCodes) {
        this.numberOfCodes = numberOfCodes;
    }

    
    
    // utility methods
    // add a code to the vactor of codes
    public void addCode(String code) {
        int codes = getNumberOfCodes();
        if (codes < MAXIMUM_CODES) {
            this.creditCardCodes.add(code);
            codes = codes + 1;
            setNumberOfCodes(codes);
        }
    }
    
    // encrypt a card
    public String encrypt(String cardNumber) {
        String code = "";
        int codes = getNumberOfCodes();
        
        int offset = (cipher.getCipherCode() + codes) % 16;
        
        code = cipher.encrypt(cardNumber, cipher.getCipherCode() + numberOfCodes);
        
        return code;
    }
     
    // check if the card has such a code
    public boolean hasCode(String code) {
        return creditCardCodes.contains(code);
    }
    
    // check if the max code size has been reached
    public boolean isMaxSizeReached() {
        return getNumberOfCodes() == MAXIMUM_CODES;
    }
    
    // toString
    @Override
    public String toString() {
        return String.format("credit card = %s, %s", getCreditCardNumber(), getCreditCardCodes());
        //return "CreditCard{" + "creditCardNumber=" + creditCardNumber + ", creditCardCodes=" + creditCardCodes + '}';
    }
    
    
}
