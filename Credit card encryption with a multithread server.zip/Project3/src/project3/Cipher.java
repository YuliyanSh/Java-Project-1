package project3;

// a Substitution cipher (CeaserCipher)
public class Cipher {
    // instance variables
    private final int CIPHER_CODE; // the offset used for encrypting and decrypting
    private final int NUMBER_SIZE = 10; // numbers from 0 to 9
    private final int STARTING_SYMBOL   = (int) '0';

    
    // constructors
    public Cipher(int cipher) {
        if (cipher > 0) {
            this.CIPHER_CODE = cipher;
        } else {
            this.CIPHER_CODE = 1;
        }    
    }

    public Cipher() {
        this(1);
    }

    
    // instance methods
    public int getCipherCode() {
        return CIPHER_CODE;
    }

    public String encrypt(String plainText, int cipher){   
        char[] plainTextChars = plainText.toCharArray();
        char[] cipherTextChars = new char[plainTextChars.length];
        
        for (int i = 0; i < cipherTextChars.length; i++) {
            cipherTextChars[i] = (char) (STARTING_SYMBOL + (plainTextChars[i] - STARTING_SYMBOL + cipher ) % NUMBER_SIZE);
        }
        
        return new String(cipherTextChars);
    }
    
    public String decrypt(String cipherText, int cipher){
        char[] cipherTextChars = cipherText.toCharArray();
        char[] plainTextChars = new char[cipherTextChars.length];
        
        for (int i = 0; i < cipherTextChars.length; i++) {
            plainTextChars[i] = (char) (STARTING_SYMBOL + (cipherTextChars[i] - STARTING_SYMBOL - cipher + NUMBER_SIZE) % NUMBER_SIZE );
            
        }
        
        return new String(plainTextChars);    
    }      
      
} // end of class Cipher
