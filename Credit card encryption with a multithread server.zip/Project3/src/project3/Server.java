package project3;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class Server extends Application {
    // instance variables
    // networking variables
    private ServerSocket server; //server socket
    private Socket socket; //socket to communicate with client
    // utility variables
    private Vector<User> users; //list of users registered 
    private File file;
    private ExecutorService threadExecutor;
     
    
    // UI controls for user registering
    private Button btnSortByNumber; // sort cards information by number
    private Button btnSortByCode; // sort cards information by code
    private Button btnCreateUser; // register a new user
    private CheckBox[] checkboxArray; // choose the level of access for the new user
    private Label lblSort; // label for txtSortFile
    private Label lblUsername; // label for txtUsername
    private Label lblPassword; // label for lblPassword
    private TextArea txaDisplayArea; // display server informaion
    private TextField txtSortFile; // input file destination for sorting 
    private TextField txtUsername; // input username
    private TextField txtPassword; // input password  
    
    
    public Server() {
        // reading users from XML file using XStream       
        XStream xstream = new XStream(new DomDriver());
        file = new File("users.xml");
        if (file.exists() && !file.isDirectory()) {
            xstream.alias("UsersVector", Vector.class);
            xstream.alias("User", User.class);
            users = (Vector<User>) xstream.fromXML(file);

        } else { // if file doesn't exist create empty Vector
            users = new Vector<User>();
        }  
        
        threadExecutor = Executors.newCachedThreadPool();
    }
    
    
    @Override
    public void start(Stage primaryStage) {
        // set root of stage as a VBox
        VBox root = new VBox();
        root.setPadding(new Insets(14));
        root.setSpacing(8);
        root.setAlignment(Pos.CENTER);
        
        // initializing UI controls far cards
        txaDisplayArea = new TextArea();
        lblSort = new Label("Enter sorting destination file name ");
        txtSortFile = new TextField();
        txtSortFile.setPromptText("Enter file name");   
        btnSortByNumber = new Button("Sort by card number");
        btnSortByCode = new Button("Sort by code");
        
        lblUsername = new Label("Username:");
        txtUsername = new TextField();
        txtUsername.setPromptText("Enter username");
        lblPassword = new Label("Password:");
        txtPassword = new TextField();
        txtPassword.setPromptText("Enter password");
        checkboxArray = new CheckBox[2];
        checkboxArray[0] = new CheckBox("Able to encrypt");
        checkboxArray[1] = new CheckBox("Able to decrypt");
        btnCreateUser = new Button("Create new user");
        
        
        // defining HBox for horizontal button placement
        HBox buttonBox = new HBox();
        HBox.setHgrow(btnSortByCode, Priority.ALWAYS);
        HBox.setHgrow(btnSortByNumber, Priority.ALWAYS);
        buttonBox.setSpacing(14);
        btnSortByCode.setMaxWidth(Double.MAX_VALUE);
        btnSortByNumber.setMaxWidth(Double.MAX_VALUE);
        buttonBox.getChildren().addAll(btnSortByNumber, btnSortByCode);
        
        root.getChildren().addAll(txaDisplayArea, lblSort, txtSortFile, buttonBox);
                    
        // define HBox for horizontal controls placement
        HBox usernameBox = new HBox();
        HBox.setHgrow(lblUsername, Priority.ALWAYS);
        HBox.setHgrow(txtUsername, Priority.ALWAYS);
        buttonBox.setSpacing(14);
        lblUsername.setMaxWidth(Double.MAX_VALUE);
        txtUsername.setMaxWidth(Double.MAX_VALUE);
        usernameBox.getChildren().addAll(lblUsername, txtUsername);
        
        root.getChildren().add(usernameBox);
        
        // define HBox for horizontal controls placement
        HBox passwordBox = new HBox();
        HBox.setHgrow(lblPassword, Priority.ALWAYS);
        HBox.setHgrow(txtPassword, Priority.ALWAYS);
        buttonBox.setSpacing(14);
        lblPassword.setMaxWidth(Double.MAX_VALUE);
        txtPassword.setMaxWidth(Double.MAX_VALUE);
        passwordBox.getChildren().addAll(lblPassword, txtPassword);
        
        root.getChildren().add(passwordBox);
        
        for (int i = 0; i < checkboxArray.length; i++) {
            root.getChildren().addAll(checkboxArray[i]);
        }
        
        root.getChildren().add(btnCreateUser);
        
        // event handlers for buttons
        btnCreateUser.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // variables
                String username;
                String password;
                UserAccess newUserAccess;     
                
                // get information from textFields
                username = txtUsername.getText();
                password = txtPassword.getText();
                newUserAccess = null; // default access
                
                // check access level of the new user
                if (checkboxArray[0].isSelected() && !checkboxArray[1].isSelected()) {
                    newUserAccess = UserAccess.ENCRYPT;
                }
                if (!checkboxArray[0].isSelected() && checkboxArray[1].isSelected()) {
                    newUserAccess = UserAccess.DECRYPT;
                }
                if (checkboxArray[0].isSelected() && checkboxArray[1].isSelected()) {
                    newUserAccess = UserAccess.ENCRYPT_DECRYPT;
                }  
                
                // validate input information
                if (!isValidUsername(username)) {
                    alertMessage("Login failure", 
                            "Incorrect username format", 
                            "Please, input a username contatining only "
                            + "lowercase and uppercase letters.");
                } else if (!isValidPassword(password)) {
                    alertMessage("Login failure", 
                            "Incorrect password format", 
                            "Please, input a password with a minimum length of 8 and contatining only "
                            + "lowercase letters, uppercase letters and numbers.");
                } else {
                    createNewUser(username, password, newUserAccess);
                }
                
                
            }
        });
        
        btnSortByNumber.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (!users.isEmpty()) {
                    try {
                        String fileName = String.format("%s.txt", txtSortFile.getText());
                        // check if there isn't an inputed file name
                        if (fileName.equals(".txt")) {       
                            fileName = "Information_sorted_by_numbers.txt";       
                        } 
                        
                        Path path = Paths.get(fileName);
                        PrintWriter writer = new PrintWriter(Files.newBufferedWriter(path), true);
                        
                        for (Iterator<User> iterator = users.iterator(); iterator.hasNext();) {
                            User next = iterator.next();
                            next.sortUsersByCardNumber(fileName, writer);
                        }
                        
                        writer.close();
                        
                        displayMessage("Sorted credit cards by code saved in "
                                 + fileName + "\n");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    displayMessage("No users to sort\n");
                }   
            }
        });
        
        btnSortByCode.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (!users.isEmpty()) {
                    try {
                        String fileName = String.format("%s.txt", txtSortFile.getText());
                        // check if there isn't an inputed file name
                        if (fileName.equals(".txt")) {       
                            fileName = "Information_sorted_by_codes.txt";       
                        } 
                        
                        Path path = Paths.get(fileName);
                        PrintWriter writer = new PrintWriter(Files.newBufferedWriter(path), true);
                        
                        for (Iterator<User> iterator = users.iterator(); iterator.hasNext();) {
                            User next = iterator.next();
                            next.sortUsersByCardCode(fileName, writer);
                        }
                        
                        writer.close();
                        
                        displayMessage("Sorted credit cards by code saved in "
                                 + fileName + "\n");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    displayMessage("No users to sort\n");
                }   
            }
        });
        
        
        Scene scene = new Scene(root, 350, 450);          
        
        // shutdown thread gracefully
        primaryStage.setOnCloseRequest(evt -> stop());
        primaryStage.setTitle("Server");
        primaryStage.setScene(scene);
        primaryStage.setMinHeight(450);
        primaryStage.setMinWidth(350);
        primaryStage.show();
        
        // start server in separate Thread
        Thread thread = new Thread(() -> runServer());
        thread.start();
        
    } // end of method start

    // create new user
    public void createNewUser(String username, String password, UserAccess userAccess) {
        User newUser = new User(username, password, userAccess);
        XStream xstream = new XStream(new DomDriver());
        
        // check if user exists
        if (userExists(newUser)) {
            displayMessage("User " + newUser.getUsername() + " already exist\n");
        
        // user doesn't exist     
        } else {
            // add new user to users vector and write to XML file
            users.add(newUser);
            
            try (PrintWriter writer = new PrintWriter(file.getAbsoluteFile())) {
                    xstream.alias("UsersVector", Vector.class);
                    xstream.alias("User", User.class);
                    xstream.toXML(users, writer);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            
            displayMessage("User " + newUser.getUsername() + " created!\n");
        }
    }
    
    // check if a user already exists
    public boolean userExists(User user) {
        boolean result = false;
        
        if (users == null) {
                return false;
            }   
        
        for (Iterator<User> iterator = users.iterator(); iterator.hasNext();) {
            User next = iterator.next();
            
            if (next.getUsername().equals(user.getUsername()) && 
                    next.getPassword().equals(user.getPassword())) {
                result = true;
            }
        }
        
        return result;
    }
    
    // open an alert message to the server
    private void alertMessage(String title, String headerText, String ContentText) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(ContentText);
        alert.showAndWait();
    }
    
    // validate username syntax
    private boolean isValidUsername(String username) {
        // containing only lowercase and uppercase letters
        return username.matches("[a-zA-Z]+");
    }    

    // validate password syntax
    private boolean isValidPassword(String password) {
        // containing only lowercase, uppercase letters and numbers
        return password.matches("[a-zA-Z0-9]{8,}+");
    }
    
    public void runServer() {
        try // set up server to receive connections; process connections
        {
            server = new ServerSocket(12345, 100); // create ServerSocket
            displayMessage("Waiting for connection\n");
            while (true) {
                waitForConnection(); // wait for a connection      

            }
        } catch (IOException ioException) {
            System.out.println("Server has stopped");
        } // end catch
        stop();
        
    } // end of method runServer
    
    private void waitForConnection() throws IOException {
        socket = server.accept(); // listening for a connection to serverSocket
        
        threadExecutor.execute(new ClientHandler(socket)); // handle client in different Thread in the ThreadPool
        displayMessage("Connection  received from: "
                + socket.getInetAddress().getHostName() + "\n"); // displaying connected client address
    } // end method waitForConnection
    
    // display message to the txaDisplayArea of the server's UI
    private void displayMessage(String message) {
        Platform.runLater(()
                -> { // updates displayArea
                    txaDisplayArea.appendText(message); // append message
                }
      ); // end call to Platfrom.runLater
        
    } // end method displayMessage
    
    // shutdown the application and all running threads
    @Override
    public void stop() {
        XStream xstream = new XStream(new DomDriver());
        try (PrintWriter writer = new PrintWriter(file.getAbsoluteFile())) {
                    xstream.alias("UsersVector", Vector.class);
                    xstream.alias("User", User.class);
                    xstream.toXML(users, writer);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
        
        Platform.exit();//graceful shutdown
        threadExecutor.shutdown();
        System.out.println("Server shuts down.");
        System.exit(0); // terminate the JVM

    } //end method stop
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    // a inner class for handling clients
    private class ClientHandler implements Runnable {
        // instance variables
        private User currentUser; // current client
        private Socket client; // connection to client
        private ObjectOutputStream output; // output stream to client
        private ObjectInputStream input; // input stream from client

        
        // constructors
        public ClientHandler(Socket socket) {
            this.client = socket;

            try {// obtain streams from Socket
                output = new ObjectOutputStream(socket.getOutputStream());
                output.flush();
                input = new ObjectInputStream(socket.getInputStream());

            } catch (IOException ioException) {
                ioException.printStackTrace();
                System.exit(1);
            }
        }
                
        
        @Override
        public void run() {
            try {
                // check if user has entered his login information
                if (loggedIn()) { // if user has entered his account
                    String action;
                    do {
                        action = (String) input.readObject(); // requested user operation
                        switch (action) {                  
                            case "Encrypt":
                                encryptCard();
                                break;
                            case "Decrypt":
                                decryptCard();
                                break;
                        }
                    } while (!action.equals("End")); // until client closes his application
                    // user has left
                    displayMessage(currentUser + " Terminated connection\n\n");
                    // close connection to the client
                    closeConnection();
                } else { // user has incorrectly inputed his information
                    displayMessage("User failed to log in, closing the connection!\n");
                    // close connection to the client
                    closeConnection();
                }

            } catch (IOException ioException) {
                System.out.println("Server has stopped");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            finally {
                // close connection to the client
                closeConnection();
            }
            
        } // end of method run
        
        // check if the user can be logged in to the system
        public boolean loggedIn() throws IOException, ClassNotFoundException {
            // read user's information
            String username = (String) input.readObject();
            String password = (String) input.readObject();
            
            // display message to the server
            displayMessage(username + " trying to log in\n");

            // check if user exists in the database
            if (!validateUser(username, password)) { // check if input is valid
                output.writeObject("Logging unsuccesful");
                output.flush();
                return false;
            }
            
            displayMessage(username + " logged in\n"); //successful user verification
            output.writeObject("Logging successful");
            //output.writeObject(currentUser.getAccess());
            output.flush();
            
            return true;
            
        } // end of method loggedIn
        
        // check if user exists in the system
        public boolean validateUser(String username, String password) {
            if (users == null) {
                return false;
            }
            
            // iterate throught users              
            for (Iterator<User> iterator = users.iterator(); iterator.hasNext();) {
                User next = iterator.next();
                System.out.println(next);
                // check if the new user matches an already existing one
                if ( username.equals(next.getUsername()) && password.equals(next.getPassword()) ) {
                    currentUser = next;
                    return true;
                }          
                
            }
            
            // user doesn't exist
            return false;
            
        } // end of method validateUser
        
        // encrypt a card, send by the client
        public synchronized void encryptCard() throws IOException, ClassNotFoundException {
            String number = (String) input.readObject(); // read card number from client
            number = number.replace(" ", ""); // remove whitespaces

            // check if user has access
            if (!(currentUser.getAccess() == UserAccess.ENCRYPT 
                    || currentUser.getAccess() == UserAccess.ENCRYPT_DECRYPT)) {
                output.writeObject("Access denied");
                output.flush();
                
            // check is the number is Luhn valid        
            } else if (!validateCard(number)) { 
                output.writeObject("Invalid number");
                output.flush();
                
            // encrypt card         
            } else {
                String encryptedNumber = currentUser.encryptCard(number);
                
                // check if there are any remaining attempts left to encrypt
                if (encryptedNumber.equals("Max size reached")) {
                    output.writeObject("Too many attempts");
                    output.flush();
                    
                // there is space left to encrypt
                } else {               
                    output.writeObject("Encryption successful");
                    //output.flush();
                    output.writeObject(encryptedNumber);
                    output.flush();
                    displayMessage("User " + currentUser + " successfuly encrypted "
                            + "credit card number :\n" + number + "\n");
                }            
                
            }

        } // end of method encryptCard
        
        // decrypt a card, send by the client
        public synchronized void decryptCard() throws IOException, ClassNotFoundException {         
            String code = (String) input.readObject(); // read code from client
            code = code.replace(" ", ""); // remove whitespaces
            
            //check iif user has access to decrypt
            if (!(currentUser.getAccess() == UserAccess.DECRYPT
                    || currentUser.getAccess() == UserAccess.ENCRYPT_DECRYPT)) {
                output.writeObject("Access denied");
                output.flush();
                
            // decrypt card   
            } else {
                String cardNumber = currentUser.decryptCard(code);
                
                // check if card with such code exist 
                if (cardNumber.equals("Code doesn't exist")) {
                    output.writeObject("Doesn't exist");
                    output.flush();
                
                // card exists
                } else {
                    output.writeObject("Decryption successful");
                    output.writeObject(cardNumber);
                    output.flush();
                    displayMessage("User " + currentUser + " successfuly decrypted "
                            + "credit card number :\n" + cardNumber + "\n");
                }
                     
            }
        } // end of method decrypt
        
        // validate a card number
        public boolean validateCard(String number) {
            // remove white spaces
            number = number.replaceAll(" ", "");
            Long cardNumber = Long.parseLong(number);
            // use Luhn's formula to validate the card
            return ValidateCreditCardNumber.isValid(cardNumber);
        }
        
        // close connecion to client
        public void closeConnection() {
            try {
                if (output != null) {
                    output.close(); // close output stream
                }
                if (input != null) {
                    input.close(); // close input stream 
                }
                if (socket != null) {
                    socket.close(); // close socket
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            
        } // end method closeConnection
        
    } // end of inner class ClientHandler
    
} // end of class Server
