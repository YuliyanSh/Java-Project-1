package project3;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.util.stream.Stream;

// users of the system (clients)
public class User implements Serializable{
    // instance variables
    private String username; // name of user
    private String password; // password of user
    private UserAccess access; // type of access granted to user
    private Vector<CreditCard> creditCards; // user's credit cards

    
    // constructors
    public User(String username, String password, UserAccess access, Vector<CreditCard> creditCards) {
        setUsername(username);
        setPassword(password);
        setAccess(access);
        setCreditCards(creditCards);
    }

    public User(String username, String password, UserAccess access) {
        this(username, password, access, new Vector<CreditCard>());
    }
    
    public User(String username, String password) {
        this(username, password, null, new Vector<CreditCard>());
    }
    
    public User(User user) {
        this(user.getUsername(), user.getPassword(), user.getAccess(), user.getCreditCards());
    }
 
    
    // instance methods
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public UserAccess getAccess() {
        return access;
    }

    public void setAccess(UserAccess access) {
        this.access = access;
    }

    public Vector<CreditCard> getCreditCards() {
        return creditCards;
    }

    public void setCreditCards(Vector<CreditCard> creditCards) {
        this.creditCards = creditCards;
    }

    
    // utility methods
    // add a credit card number to the list of card numbers
    public void addCreditCard(CreditCard creditCard) {
        creditCards.add(creditCard);
    }
    
    // check if creditCards has a specific card number
    public boolean hasCard(String number) {      
        for (Iterator<CreditCard> iterator = creditCards.iterator(); iterator.hasNext();) {
            if (number.equals(iterator.next().getCreditCardNumber())) {
                return true;
            }           
        }
        
        return false;
    }
    
    // get index of credit card
    public int getIndexOfCard(String number) {
        int counter = 0;
        int result = 0;
        
        for (Iterator<CreditCard> iterator = creditCards.iterator(); iterator.hasNext();) {
            if (number.equals(iterator.next().getCreditCardNumber())) {
                result = counter;
            }  
            counter++;
        }
        
        return result;
    }
    
    // add code to credit card number
    public String encryptCard(String number) {
        String result = ""; // returned result
        String code = ""; // encrypted number
        
        // check if card exists
        if (hasCard(number)) {
            // get index of the card
            int index = getIndexOfCard(number);
            
            // check if there is space for a new code
            if (creditCards.get(index).isMaxSizeReached()) {
                result = "Max size reached";
                return result;
            }        
                     
            // encrypt credit card number
            code = creditCards.get(index).encrypt(number);
            // add encrypted code to the credit card number
            creditCards.get(index).addCode(code);
            
            result = code;
        }
        // new credit card
        else {         
            // create a new CreditCard object
            CreditCard newCardNumber = new CreditCard(number);      
            // encrypt credit card number      
            code = newCardNumber.encrypt(number);
            // add code to the new CreditCard object
            newCardNumber.addCode(code);
            // add new CreditCard object to the vector of credit cards
            addCreditCard(newCardNumber);
            
            result = code;
        }
        
        return result;
    }
    
    // check if there is a code in creditCards 
    public boolean hasCode(String code) {      
        for (Iterator<CreditCard> iterator = creditCards.iterator(); iterator.hasNext();) {
            if (iterator.next().hasCode(code)) {
                return true;
            }           
        }
        
        return false;
    }
    
    // get index of code
    public String getNameOfCard(String code) {
        int counter = 0;
        String result = "";
        
        for (Iterator<CreditCard> iterator = creditCards.iterator(); iterator.hasNext();) {
            if (iterator.next().hasCode(code)) {
                result = creditCards.get(counter).getCreditCardNumber();
            }  
            counter++;
        }
        
        return result;
    }
    
    // get credit card number corresponding to a code
    public String decryptCard(String code) {
        String result = ""; // returned result
        String number = ""; // encrypted number
        
        // check if code exists
        if (hasCode(code)) {
            // get index of the card
            return getNameOfCard(code);
        }
        else {
            result = "Code doesn't exist";
        }
        
        return result;
    }
    
    // sort information by card numbers and save it to an external file
    public void sortUsersByCardNumber(String file, PrintWriter writer) throws IOException {
        // append to file
        // user information
        writer.printf(this.toString());
        // names of columns
        writer.printf("%-16s\t%s%n", "Credit card numbers", "Credit card codes");
        
        // card numbers and codes, sorted by numbers
        creditCards.sort((e1, e2) -> e1.getCreditCardNumber().compareTo(e2.getCreditCardNumber()));
        for (Iterator<CreditCard> iterator = creditCards.iterator(); iterator.hasNext();) {
            CreditCard next = iterator.next();
            
            for (Iterator<String> iterator1 = next.getCreditCardCodes().iterator(); iterator1.hasNext();) {
                String code = iterator1.next();
                //writer.println(code);
                writer.printf("%-16s\t%s%n", next.getCreditCardNumber(), code);
            }
                 
        }
        writer.println();     
        
    } // end of method sortUsersByCardNumber
    
    // sort information by codes and save it to an external file
    public void sortUsersByCardCode(String file, PrintWriter writer) throws IOException {
        // append to file
        // user information
        writer.println(this.toString());
        // names of columns
        writer.printf("%-16s\t%s%n", "Credit card numbers", "Credit card codes");     
        
        // card numbers and codes, sorted by codes
        creditCards.sort((e1, e2) -> e1.getCreditCardNumber().compareTo(e2.getCreditCardNumber()));
        for (Iterator<CreditCard> iterator = creditCards.iterator(); iterator.hasNext();) {
            CreditCard next = iterator.next();
 
            
            for (Iterator<String> iterator1 = next.getCreditCardCodes().iterator(); iterator1.hasNext();) {
                String code = iterator1.next();
                //writer.println(code);
                writer.printf("%-16s\t%s%n", next.getCreditCardNumber(), code);
            }
                 
        }
        writer.println();
        
    }
    
    // toString
    @Override
    public String toString() {
        return String.format("username = %s, password = %s, access = %s%n", getUsername(), getPassword(), getAccess());    
    } 
    
} // end of class User
