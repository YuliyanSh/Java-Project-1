package project3;

// validate a credit card number using Luhn's algorithm
// long number1 = 4388576018402626L; // invalid
// long number2 = 4388576018410707L; // valid
// valid numbers : 38520000023237, 6011111111111117, 371449635398431

public class ValidateCreditCardNumber {
    
    /** Return true if the card number is valid */
    public static boolean isValid(long number) {
        return (13 <= getSize(number) && 
                getSize(number) <= 16 && 
                (getPrefix(number, 1) == 4 ||
                getPrefix(number, 1) == 5 ||
                getPrefix(number, 2) == 37 ||
                getPrefix(number, 1) == 6) && 
                (sumOfDoubleEvenPlace(number) + sumOfOddPlace(number)) % 10 == 0);
    }
    
    /** Get the result from Step 2 */
    public static int sumOfDoubleEvenPlace(long number) {
        // declaration
        int size;
        int counter;
        int sum;
        
        // initialisation
        size = getSize(number);
        counter = 0;
        sum = 0;
        
        // processing
        for (int i = 1; i <= size; i++) {
            if (i % 2 == 0) { 
                sum = sum + getDigit(2 * ((int)(number % 10)));
                number = number / 10;   
            } else {
                number = number / 10;
            }
        }

        // output
        return sum;
    }
    
    /** Return this number if it is a single digit, otherwise,
    * return the sum of the two digits */
    public static int getDigit(int number) {
        return (number % 10 == 0 && number != 10 ? number : number / 10 + number % 10);
    }
    
    /** Return sum of odd-place digits in number */
    public static int sumOfOddPlace(long number) {
        // declaration
        int size;
        int counter;
        int sum;
        
        // initialisation
        size = getSize(number);
        counter = 0;
        sum = 0;
        
        // processing
        for (int i = 1; i <= size; i++) {
            if (i % 2 != 0) { 
                sum = sum + (int)(number % 10);
                number = number / 10;   
            } else {
                number = number / 10;
            }
        }

        // output
        return sum;
    }

    /** Return true if the digit d is a prefix for number */
    public static boolean prefixMatched(long number, int d) {
        // declaration
        int size;
        long numberPrefix;
        
        //initialisation
        size = getSize(d);
        numberPrefix = getPrefix(number, size);
        
        // output
        return numberPrefix == d;
    }
            
    /** Return the number of digits in d */
    public static int getSize(long d) {
        // declaration
        int counter;
        long quotient;
        long remainder;
        
        // initialisation
        counter = 0;
        quotient = d;
        remainder = d;
        
        // processing
        // find size of number
        do {
            remainder = quotient % 10;
            quotient = quotient / 10;
            counter++;
        } while (quotient != 0);
        
        // output
        // return size
        return counter;
    }
            
    /** Return the first k number of digits from number. If the
    * number of digits in number is less than k, return number. */
    public static long getPrefix(long number, int k) {
        // declaration
        int size;
        
        // initialisation
        size = getSize(number);
        
        // processing
        // check if prefix is longer or equal than number
        if (k >= size) {
            return number;
        }
        // else return the first k numbers
        for (int i = 0; i < size-k; i++) {
            number = number / 10;
        }
        
        // output
        // return first k numbers
        return number;       
    } 
    
} // end of class ValidateCreditCardNumber
