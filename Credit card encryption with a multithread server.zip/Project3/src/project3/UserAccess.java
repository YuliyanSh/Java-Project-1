package project3;

// type od access for users
public enum UserAccess {
    ENCRYPT,         // user can encrypt only
    DECRYPT,         // user can decrypt only
    ENCRYPT_DECRYPT, // user can encrypt and decrypt
    
} // end of enum UserAccess
