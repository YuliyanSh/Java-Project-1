package project3;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class Client extends Application {
    // instance variables
    // networking variables
    private Socket client; //socket to communicate with server
    private ObjectOutputStream output; // output stream to client
    private ObjectInputStream input; // input stream from client
    private final String serverAddress = "localhost";
    private final int port = 12345;
    // UI virables
    private Label lblUser; // information label for txtUser
    private Label lblPassword; // information label for txtPassword
    private TextField txtUser; // input for user name
    private PasswordField pswPassword; // input for user password
    private Button btnLogin;  // login button
    private Stage currentStage;  // currently shown stage
    
    
    @Override
    public void start(Stage primaryStage) { 
        // set root parameters
        VBox root = new VBox();
        root.setPadding(new Insets(14));
        root.setSpacing(10);
        root.setAlignment(Pos.CENTER); 
        
        // set UI elements
        txtUser = new TextField();
        txtUser.setPromptText("Enter username");
        pswPassword = new PasswordField();
        pswPassword.setPromptText("Enter password");
        lblUser = new Label("Username:");
        lblPassword = new Label("Password:");
        btnLogin = new Button("Login");
        
        // eventHandler for btnLogin
        btnLogin.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // variables
                String username;
                String password;
                
                // get information from textFields
                username = txtUser.getText();
                password = pswPassword.getText();
                
                // validate input information
                if (!isValidUsername(username)) {
                    alertMessage("Login failure", 
                            "Incorrect username format", 
                            "Please, input a username contatining only "
                            + "lowercase and uppercase letters.");
                } else if (!isValidPassword(password)) {
                    alertMessage("Login failure", 
                            "Incorrect password format", 
                            "Please, input a password with a minimum length of 8 and contatining only "
                            + "lowercase letters, uppercase letters and numbers.");
                } else {
                    try {  // connect to server, get streams            
                        connectToServer(); // create a Socket to make connection
                        getStreams(); // get the input and output streams
                        // if login in server successful
                        if (isLoggedIn(username, password)) { 
                            alertMessage("Login success", "Access granted", "You have successfully logged in.");
                            txtUser.clear();
                            pswPassword.clear();
                            changeStage(); // replace the stage with a new one 
                        } else {
                            alertMessage("Login failure", "Access denied", "Invalid user or password.");
                            endConnection();
                        }

                    } catch (IOException e) {
                        alertMessage("Login failure", "Access denied", "Server is offline so the connection will be terminated.");
                    }
                }
            } 
   
        });
        
        root.getChildren().addAll(lblUser, txtUser, lblPassword, pswPassword, btnLogin);

        Scene scene = new Scene(root, 350, 300);

        primaryStage.setOnCloseRequest(evt -> Platform.exit());
        primaryStage.setTitle("User login");
        primaryStage.setScene(scene);
        primaryStage.setMinHeight(200);
        primaryStage.setMinWidth(200);
        currentStage = primaryStage;
        primaryStage.show();
        
    } // end of method start
    
    
    // open an alert message to the user
    private void alertMessage(String title, String headerText, String ContentText) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(ContentText);
        alert.showAndWait();
    }
    
    // validate username syntax
    private boolean isValidUsername(String username) {
        // containing only lowercase and uppercase letters
        return username.matches("[a-zA-Z]+");
    }    

    // validate password syntax
    private boolean isValidPassword(String password) {
        // containing only lowercase, uppercase letters and numbers
        return password.matches("[a-zA-Z0-9]{8,}+");
    }

    // try to connect to server
    private void connectToServer() throws IOException {
        // create a socket to make connection to server
        client = new Socket(serverAddress, port);
        if (client == null) {
            Platform.exit();
        }  
    }
    
    // get input and output streams
    private void getStreams() throws IOException {
        // set up output stream for objects
        output = new ObjectOutputStream(client.getOutputStream());
        output.flush();
        // set up input stream for objects
        input = new ObjectInputStream(client.getInputStream());
    }
    
    // validate if user has successfully logged in
    private boolean isLoggedIn(String username, String password) throws IOException {
        // send log in information to the server    
        try {
            output.writeObject(username);
            output.flush();
            output.writeObject(password);
            output.flush(); // flush output to server
        } catch (IOException e) {
            alertMessage("Error", "System error", "Error writing object");
        }
        // response from the server
        String confirmationMessage = "";
        
        try {
            confirmationMessage = (String) input.readObject();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        // check if we have successfully connected to the server
        return confirmationMessage.equals("Logging successful");
    }
    
    
    private void changeStage() {
        // set up UI components
        HBox buttonsHBox = new HBox();
        Label lblCreditCardNumber = new Label("Enter credit card number:");
        TextField txtCreditCardNumber = new TextField();
        txtCreditCardNumber.setPromptText("Enter a credit card number");
        Button btnEncrypt = new Button("Encrypt");
        Button btnDecrypt = new Button("Decrypt");
        TextArea txaResult = new TextArea();

        buttonsHBox.setSpacing(14);
        HBox.setHgrow(btnEncrypt, Priority.ALWAYS);
        HBox.setHgrow(btnDecrypt, Priority.ALWAYS);
        btnEncrypt.setMaxWidth(Double.MAX_VALUE);
        btnDecrypt.setMaxWidth(Double.MAX_VALUE);
        txaResult.setEditable(false);
        
        buttonsHBox.getChildren().addAll(btnEncrypt, btnDecrypt);
        
        // eventHandler for btnEncrypt
        btnEncrypt.setOnAction(event -> {
            String encryptedNumber = encryptNumber(txtCreditCardNumber.getText());
            if (encryptedNumber != null) {
                txaResult.appendText(String.format("Encrypted number: %s%n", encryptedNumber));
            }
        });

        btnDecrypt.setOnAction(event -> {
            String cardNumber = decryptCode(txtCreditCardNumber.getText());
            if (cardNumber != null) {
                txaResult.appendText(String.format("Decrypted card number: %s%n", cardNumber));
            }
        });

        Scene scene = currentStage.getScene();
        VBox root = (VBox) scene.getRoot();
        root.getChildren().clear();
        root.getChildren().addAll(lblCreditCardNumber, txtCreditCardNumber, buttonsHBox, txaResult);

        currentStage.setOnCloseRequest(evt -> {
            endConnection();
            Platform.exit();
        });
        currentStage.setScene(scene);
        currentStage.setTitle("Card encryption/decryption");
        currentStage.setMinHeight(200);
        currentStage.setMinWidth(200);
        currentStage.show();
    }
    
    // encrypt a credit card number or show an error
    private String encryptNumber(String number) {
        String encyptedNumber = null;
        
        try {
            // send data to server (command for encryption and number to encrypt)
            output.writeObject("Encrypt");
            output.flush();
            output.writeObject(number);
            output.flush();

            // recieve response from server
            String response = (String) input.readObject();

            switch (response) {
                case "Access denied":
                    alertMessage("Error", "Insuficient privilages", "You don't have permission to encrypt!");
                    break;
                case "Invalid number":
                    alertMessage("Error", "Invalid information", "You have entered an invalid card number!");
                    break;
                case "Too many attempts":
                    alertMessage("Error", "Limit reached", "You can't encrypt a card more than 12 times!");
                    break;
                case "Encryption successful":
                    encyptedNumber = (String) input.readObject();
                    alertMessage("Successful encription", "Encrypted card number ", encyptedNumber);

            }

        } catch (IOException | ClassNotFoundException e) {
            lostConnectionError();
        }

        return encyptedNumber;
    }

    // decrypt a code or show an error
    private String decryptCode(String code) {
        String cardNumber = null;

        try {
            // send data to server (command for decryption and number to decrypt)
            output.writeObject("Decrypt");
            output.writeObject(code);
            output.flush();
            
            // recieve response from server
            String response = (String) input.readObject();

            switch (response) {
                case "Access denied":
                    alertMessage("Error", "Insuficient privilages", "You don't have decrypt access!");
                    break;
                case "Doesn't exist":
                    alertMessage("Error", "Invalid information", "You have entered an invalid code number!");
                    break;
                case "Decryption successful":
                    cardNumber = (String) input.readObject();
                    alertMessage("Successful encription", "Decrypted card number", cardNumber);

            }

        } catch (IOException | ClassNotFoundException e) {
            lostConnectionError();
        }
        return cardNumber;
    }
    
    // end connection to the server
    private void endConnection() {
        try {
            // send data to server (message indicating termination)
            output.writeObject("End");
            output.flush();
            // close output stream
            if (output != null) {
                output.close();
            }
            // close input stream
            if (input != null) {
                input.close();
            }
            // close socket
            if (client != null) {
                client.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // close client's socket because server has been terminated
    private void lostConnectionError() {
        alertMessage("Error", "Server offline", "Terminating connection to the server");
        if (client != null) {
            endConnection();
        }
        Platform.exit();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
